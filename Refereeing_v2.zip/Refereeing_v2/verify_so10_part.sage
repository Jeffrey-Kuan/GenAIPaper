"""
Verify that C_tilde_10 is central in the U_q(so_10) sub-algebra of U_q(so_12).
Checks [E_i, C_tilde_10] = [F_i, C_tilde_10] = [K_i, C_tilde_10] = 0 for i = 2,...,6.
"""
import json, os, sys, time, re as re_mod
os.chdir(os.path.dirname(os.path.abspath(__file__)))

R.<q> = QQ[]
F = R.fraction_field()
ZERO = F(0); ONE = F(1)

Q = QuantumGroup(['D', 6])
gens = Q.algebra_generators()
one = Q.one()

# === Helpers (same as verify_centrality.sage) ===

def build_K(alpha_coeffs):
    result = one
    for i, a in enumerate(alpha_coeffs):
        idx = i + 1
        if a > 0:
            for _ in range(a):
                result = result * gens['K%d' % idx]
        elif a < 0:
            for _ in range(-a):
                result = result * gens['Ki%d' % idx]
    return result

def L_to_alpha(l):
    return [l[0], l[0]+l[1], l[0]+l[1]+l[2], l[0]+l[1]+l[2]+l[3],
            (l[0]+l[1]+l[2]+l[3]+l[4]-l[5])//2,
            (l[0]+l[1]+l[2]+l[3]+l[4]+l[5])//2]

def build_E_mono(mono):
    result = one
    for idx in mono:
        result = result * gens['E%d' % idx]
    return result

def build_F_mono(mono):
    result = one
    for idx in mono:
        result = result * gens['F%d' % idx]
    return result

def compute_D_exponent(mu_L, lam_L):
    diff = [mu_L[k] - lam_L[k] for k in range(6)]
    inner1 = sum(diff[k] * mu_L[k] for k in range(6))
    rho2 = [10, 8, 6, 4, 2, 0]
    inner2 = sum(rho2[k] * mu_L[k] for k in range(6))
    return int(inner1 - inner2)

def build_term_from_fstar(fstar_entry, D_exp, K_L):
    D_val = F(q)**D_exp
    K_alpha = L_to_alpha(K_L)
    K_elem = build_K(K_alpha)
    estar = Q.zero()
    tau_estar = Q.zero()
    for et in fstar_entry['e_terms']:
        coeff = F(sage_eval(et['coeff'], locals={'q': q}))
        if coeff == 0:
            continue
        estar = estar + coeff * build_E_mono(et['monomial'])
        tau_estar = tau_estar + coeff * build_F_mono(list(reversed(et['monomial'])))
    return D_val * tau_estar * K_elem * estar

# === Build C_tilde_10 only ===

print('=== Building C_tilde_10 ===')
sys.stdout.flush()
t0 = time.time()

with open('so10_central_element_data.json') as ff:
    so10_data = json.load(ff)

La = Q.cartan_type().root_system().weight_lattice().fundamental_weights()
V1 = Q.highest_weight_module(La[1])
b1 = list(V1.basis())

ei_v1 = {}
for i in range(2, 7):
    ei_v1[i] = {}
    for j in range(12):
        result = gens['E%d' % i] * b1[j]
        if result != 0:
            for k, c in result.monomial_coefficients().items():
                if c != 0:
                    ei_v1[i][j] = (int(k), c)

so10_weight_to_v1idx = {
    'L_2': 1, 'L_3': 2, 'L_4': 3, 'L_5': 4, 'L_6': 5,
    '-L_6': 6, '-L_5': 7, '-L_4': 8, '-L_3': 9, '-L_2': 10
}
L_labels_10 = ['L_2','L_3','L_4','L_5','L_6','-L_6','-L_5','-L_4','-L_3','-L_2']
L_coords_10 = [[0,1,0,0,0,0],[0,0,1,0,0,0],[0,0,0,1,0,0],[0,0,0,0,1,0],[0,0,0,0,0,1],
                [0,0,0,0,0,-1],[0,0,0,0,-1,0],[0,0,0,-1,0,0],[0,0,-1,0,0,0],[0,-1,0,0,0,0]]

def find_path_so10(mu_label, lam_label):
    start = so10_weight_to_v1idx[lam_label]
    target = so10_weight_to_v1idx[mu_label]
    if start == target:
        return []
    from collections import deque
    queue = deque([(start, [])])
    visited = {start}
    while queue:
        cur, path = queue.popleft()
        for i in range(2, 7):
            if cur in ei_v1[i]:
                nxt, coeff = ei_v1[i][cur]
                if nxt == target:
                    return path + [i]
                if nxt not in visited:
                    visited.add(nxt)
                    queue.append((nxt, path + [i]))
    return None

C10 = Q.zero()
for i in range(10):
    mu_L = L_coords_10[i]
    rho2 = [10, 8, 6, 4, 2, 0]
    exp_pos = sum(rho2[k] * mu_L[k] for k in range(6))
    K_neg2mu = build_K(L_to_alpha([-2*mu_L[k] for k in range(6)]))
    C10 = C10 + F(q)**(-exp_pos) * K_neg2mu

print('  Diagonal K terms done [%.1fs]' % (time.time() - t0))
sys.stdout.flush()

n_found = 0
for i in range(10):
    for j in range(i+1, 10):
        mu_L = L_coords_10[i]
        lam_L = L_coords_10[j]
        gamma = tuple(mu_L[k] - lam_L[k] for k in range(6))
        gamma_alpha = tuple(L_to_alpha(list(gamma)))
        if gamma_alpha[0] != 0 or all(g == 0 for g in gamma_alpha):
            continue
        pathset = find_path_so10(L_labels_10[i], L_labels_10[j])
        if pathset is None:
            continue
        gamma_key = str(gamma_alpha)
        if gamma_key not in so10_data['weight_spaces']:
            continue
        ws = so10_data['weight_spaces'][gamma_key]
        fstar_entry = None
        for entry in ws['fstar_entries']:
            if entry['monomial'] == pathset:
                fstar_entry = entry
                break
        if fstar_entry is None:
            for entry in ws['fstar_entries']:
                if entry['monomial'] == list(reversed(pathset)):
                    fstar_entry = entry
                    break
        if fstar_entry is None:
            print('  WARNING: (%s, %s) fstar not found' % (L_labels_10[i], L_labels_10[j]))
            continue
        D_exp = compute_D_exponent(mu_L, lam_L)
        K_L = [-mu_L[k]-lam_L[k] for k in range(6)]
        C10 = C10 + build_term_from_fstar(fstar_entry, D_exp, K_L)
        n_found += 1

print('  C_tilde_10: %d off-diagonal pairs [%.1fs]' % (n_found, time.time() - t0))
sys.stdout.flush()

# === Verify C_tilde_10 commutes with so_10 sub-algebra generators ===

print()
print('=== Checking [X, C_tilde_10] = 0 for so_10 generators (i=2,...,6) ===')
sys.stdout.flush()
all_ok = True

for gen_type in ['E', 'F', 'K']:
    for i in range(2, 7):
        t1 = time.time()
        g = gens['%s%d' % (gen_type, i)]
        comm = g * C10 - C10 * g
        is_zero = (comm == Q.zero())
        elapsed = time.time() - t1
        status = 'OK' if is_zero else 'FAIL'
        print('[%s_%d, C_tilde_10] == 0? %s  [%.1fs]  %s' % (gen_type, i, is_zero, elapsed, status))
        sys.stdout.flush()
        if not is_zero:
            all_ok = False

print()
if all_ok:
    print('ALL 15 COMMUTATORS ARE ZERO. C_tilde_10 is central in U_q(so_10) sub-algebra.')
else:
    print('SOME COMMUTATORS FAILED.')
print('Total time: %.1fs' % (time.time() - t0))
