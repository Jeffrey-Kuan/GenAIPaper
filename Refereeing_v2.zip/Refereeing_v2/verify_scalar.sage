"""
Verify that C_12 acts as the claimed scalar on V(omega_1) = C^12.
Loads the already-constructed C_12 by re-running the construction,
then checks C_12 * v = scalar * v for all basis vectors v.
"""
import json, os, sys, time, re as re_mod
os.chdir(os.path.dirname(os.path.abspath(__file__)))

R.<q> = QQ[]
F = R.fraction_field()
ZERO = F(0); ONE = F(1)

Q = QuantumGroup(['D', 6])
gens = Q.algebra_generators()
one = Q.one()

# === Helpers (same as verify_centrality.sage) ===

def build_K(alpha_coeffs):
    result = one
    for i, a in enumerate(alpha_coeffs):
        idx = i + 1
        if a > 0:
            for _ in range(a):
                result = result * gens['K%d' % idx]
        elif a < 0:
            for _ in range(-a):
                result = result * gens['Ki%d' % idx]
    return result

def L_to_alpha(l):
    return [l[0], l[0]+l[1], l[0]+l[1]+l[2], l[0]+l[1]+l[2]+l[3],
            (l[0]+l[1]+l[2]+l[3]+l[4]-l[5])//2,
            (l[0]+l[1]+l[2]+l[3]+l[4]+l[5])//2]

def build_E_mono(mono):
    result = one
    for idx in mono:
        result = result * gens['E%d' % idx]
    return result

def build_F_mono(mono):
    result = one
    for idx in mono:
        result = result * gens['F%d' % idx]
    return result

def parse_K_label(K_str):
    coeffs = [0]*6
    for m in re_mod.finditer(r'([+-]?)L_(\d)', K_str):
        sign = -1 if m.group(1) == '-' else 1
        idx = int(m.group(2)) - 1
        coeffs[idx] += sign
    return coeffs

def compute_D_exponent(mu_L, lam_L):
    diff = [mu_L[k] - lam_L[k] for k in range(6)]
    inner1 = sum(diff[k] * mu_L[k] for k in range(6))
    rho2 = [10, 8, 6, 4, 2, 0]
    inner2 = sum(rho2[k] * mu_L[k] for k in range(6))
    return int(inner1 - inner2)

def build_term_from_fstar(fstar_entry, D_exp, K_L):
    D_val = F(q)**D_exp
    K_alpha = L_to_alpha(K_L)
    K_elem = build_K(K_alpha)
    estar = Q.zero()
    tau_estar = Q.zero()
    for et in fstar_entry['e_terms']:
        coeff = F(sage_eval(et['coeff'], locals={'q': q}))
        if coeff == 0:
            continue
        estar = estar + coeff * build_E_mono(et['monomial'])
        tau_estar = tau_estar + coeff * build_F_mono(list(reversed(et['monomial'])))
    return D_val * tau_estar * K_elem * estar

# === Build C_12 (same logic as verify_centrality.sage) ===

print('=== Building C_12 ===')
sys.stdout.flush()
t0 = time.time()

# --- C_tilde_10 ---
with open('so10_central_element_data.json') as ff:
    so10_data = json.load(ff)

La = Q.cartan_type().root_system().weight_lattice().fundamental_weights()
V1 = Q.highest_weight_module(La[1])
b1 = list(V1.basis())

ei_v1 = {}
for i in range(2, 7):
    ei_v1[i] = {}
    for j in range(12):
        result = gens['E%d' % i] * b1[j]
        if result != 0:
            for k, c in result.monomial_coefficients().items():
                if c != 0:
                    ei_v1[i][j] = (int(k), c)

so10_weight_to_v1idx = {
    'L_2': 1, 'L_3': 2, 'L_4': 3, 'L_5': 4, 'L_6': 5,
    '-L_6': 6, '-L_5': 7, '-L_4': 8, '-L_3': 9, '-L_2': 10
}
L_labels_10 = ['L_2','L_3','L_4','L_5','L_6','-L_6','-L_5','-L_4','-L_3','-L_2']
L_coords_10 = [[0,1,0,0,0,0],[0,0,1,0,0,0],[0,0,0,1,0,0],[0,0,0,0,1,0],[0,0,0,0,0,1],
                [0,0,0,0,0,-1],[0,0,0,0,-1,0],[0,0,0,-1,0,0],[0,0,-1,0,0,0],[0,-1,0,0,0,0]]

def find_path_so10(mu_label, lam_label):
    start = so10_weight_to_v1idx[lam_label]
    target = so10_weight_to_v1idx[mu_label]
    if start == target:
        return []
    from collections import deque
    queue = deque([(start, [])])
    visited = {start}
    while queue:
        cur, path = queue.popleft()
        for i in range(2, 7):
            if cur in ei_v1[i]:
                nxt, coeff = ei_v1[i][cur]
                if nxt == target:
                    return path + [i]
                if nxt not in visited:
                    visited.add(nxt)
                    queue.append((nxt, path + [i]))
    return None

C10 = Q.zero()
for i in range(10):
    mu_L = L_coords_10[i]
    rho2 = [10, 8, 6, 4, 2, 0]
    exp_pos = sum(rho2[k] * mu_L[k] for k in range(6))
    K_neg2mu = build_K(L_to_alpha([-2*mu_L[k] for k in range(6)]))
    C10 = C10 + F(q)**(-exp_pos) * K_neg2mu

n_found = 0
for i in range(10):
    for j in range(i+1, 10):
        mu_L = L_coords_10[i]
        lam_L = L_coords_10[j]
        gamma = tuple(mu_L[k] - lam_L[k] for k in range(6))
        gamma_alpha = tuple(L_to_alpha(list(gamma)))
        if gamma_alpha[0] != 0 or all(g == 0 for g in gamma_alpha):
            continue
        pathset = find_path_so10(L_labels_10[i], L_labels_10[j])
        if pathset is None:
            continue
        gamma_key = str(gamma_alpha)
        if gamma_key not in so10_data['weight_spaces']:
            continue
        ws = so10_data['weight_spaces'][gamma_key]
        fstar_entry = None
        for entry in ws['fstar_entries']:
            if entry['monomial'] == pathset:
                fstar_entry = entry
                break
        if fstar_entry is None:
            for entry in ws['fstar_entries']:
                if entry['monomial'] == list(reversed(pathset)):
                    fstar_entry = entry
                    break
        if fstar_entry is None:
            continue
        D_exp = compute_D_exponent(mu_L, lam_L)
        K_L = [-mu_L[k]-lam_L[k] for k in range(6)]
        C10 = C10 + build_term_from_fstar(fstar_entry, D_exp, K_L)
        n_found += 1

print('  C_tilde_10: %d off-diagonal pairs [%.1fs]' % (n_found, time.time() - t0))
sys.stdout.flush()

# --- C_tilde_12 ---
with open('central_element_data.json') as ff:
    ce_data = json.load(ff)

pair_vname_map = {
    'L_1,L_2': 'v8', '-L_2,-L_1': 'v8', 'L_1,L_3': 'v14', '-L_3,-L_1': 'v14',
    'L_1,L_4': 'v20', '-L_4,-L_1': 'v20', 'L_1,L_5': 'v25', '-L_5,-L_1': 'v25',
    'L_1,L_6': 'v30', '-L_6,-L_1': 'v30', 'L_1,-L_6': 'v31', 'L_6,-L_1': 'v31',
    'L_1,-L_5': 'v34', 'L_5,-L_1': 'v34', 'L_1,-L_4': 'v35', 'L_4,-L_1': 'v35',
    'L_1,-L_3': 'v33', 'L_3,-L_1': 'v33', 'L_1,-L_2': 'v1', 'L_2,-L_1': 'v1',
    'L_1,-L_1': 'v2',
}
pair_pathsets = {
    'L_1,L_2': [1], '-L_2,-L_1': [1], 'L_1,L_3': [1,2], '-L_3,-L_1': [2,1],
    'L_1,L_4': [1,2,3], '-L_4,-L_1': [3,2,1], 'L_1,L_5': [1,2,3,4], '-L_5,-L_1': [4,3,2,1],
    'L_1,L_6': [1,2,3,4,5], '-L_6,-L_1': [5,4,3,2,1],
    'L_1,-L_6': [1,2,3,4,6], 'L_6,-L_1': [6,4,3,2,1],
    'L_1,-L_5': [1,2,3,4,6,5], 'L_5,-L_1': [6,5,4,3,2,1],
    'L_1,-L_4': [1,2,3,4,6,5,4], 'L_4,-L_1': [4,6,5,4,3,2,1],
    'L_1,-L_3': [1,2,3,4,6,5,4,3], 'L_3,-L_1': [3,4,6,5,4,3,2,1],
    'L_1,-L_2': [1,2,3,4,6,5,4,3,2], 'L_2,-L_1': [2,3,4,6,5,4,3,2,1],
    'L_1,-L_1': [1,2,3,4,6,5,4,3,2,1],
}

fstar_data = {}
for v_name in ['v8','v14','v20','v25','v30','v31','v33','v34','v35','v1','v2']:
    with open('weights/%s/fstar_canonical.json' % v_name) as ff:
        fstar_data[v_name] = json.load(ff)

K_2L1 = build_K(L_to_alpha([2,0,0,0,0,0]))
K_m2L1 = build_K(L_to_alpha([-2,0,0,0,0,0]))
C12_new = F(q)**10 * K_2L1 + F(q)**(-10) * K_m2L1

for pair_key, pair_info in sorted(ce_data['pairs'].items()):
    if not pair_info['fstar_available']:
        continue
    v_name = pair_vname_map[pair_key]
    reversed_path = list(reversed(pair_pathsets[pair_key]))
    fstar_entry = None
    for entry in fstar_data[v_name]['entries']:
        if entry['monomial'] == reversed_path:
            fstar_entry = entry
            break
    if fstar_entry is None:
        print('  WARNING: %s fstar not found' % pair_key)
        continue
    D_exp = pair_info['D_exponent']
    K_L_parsed = parse_K_label(pair_info['K_label'])
    C12_new = C12_new + build_term_from_fstar(fstar_entry, D_exp, K_L_parsed)

C12 = C10 + C12_new
print('  C_12 built [%.1fs]' % (time.time() - t0))
sys.stdout.flush()

# === Verify scalar action on V(omega_1) ===

print()
print('=== Checking scalar action on V(omega_1) ===')
sys.stdout.flush()

expected_scalar = F(q)**12 + F(q)**8 + F(q)**6 + F(q)**4 + F(q)**2 + F(2) + F(q)**(-2) + F(q)**(-4) + F(q)**(-6) + F(q)**(-8) + F(q)**(-12)
print('Expected scalar: %s' % expected_scalar)

all_ok = True
for j in range(12):
    t1 = time.time()
    v = b1[j]
    Cv = C12 * v
    # Check if Cv == expected_scalar * v
    coeffs = Cv.monomial_coefficients()
    if len(coeffs) == 1 and int(list(coeffs.keys())[0]) == j:
        actual = list(coeffs.values())[0]
        matches = (actual == expected_scalar)
    elif len(coeffs) == 0:
        actual = F(0)
        matches = (expected_scalar == F(0))
    else:
        actual = 'multiple basis vectors'
        matches = False
    elapsed = time.time() - t1
    status = 'OK' if matches else 'FAIL'
    print('  C_12 * b[%d] = %s * b[%d]? %s  [%.1fs]  %s' % (j, expected_scalar if matches else actual, j, matches, elapsed, status))
    sys.stdout.flush()
    if not matches:
        all_ok = False

print()
if all_ok:
    print('C_12 acts as the claimed scalar on all 12 basis vectors of V(omega_1).')
else:
    print('SCALAR ACTION CHECK FAILED on some basis vectors.')
print('Total time: %.1fs' % (time.time() - t0))
